
package ilib;

import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;

public class InicioFrame {

//    public static void main(String[] args) {
//        FrmSisBib c = new FrmSisBib();
//        FlatMaterialLighterIJTheme.setup();
//        c.setVisible(true);
//    }
    
}
